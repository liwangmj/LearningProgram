Code in this folder uses GPL code by Marten Bjorkman (aka Celebrandil). More specifically, it reuses code from its CUDA SIFT implementation (http://www.csc.kth.se/~celle/).
