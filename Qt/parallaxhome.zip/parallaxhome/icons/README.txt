The scalable icons are from:

http://tango.freedesktop.org/Tango_Icon_Library

