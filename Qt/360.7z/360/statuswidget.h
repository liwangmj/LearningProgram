#ifndef STATUSWIDGET_H
#define STATUSWIDGET_H

#include <QWidget>

class statusWidget : public QWidget
{
    Q_OBJECT
public:
    explicit statusWidget(QWidget *parent = 0);
    
signals:
    
public slots:
    
};

#endif // STATUSWIDGET_H

/*
  ״̬��
*/
