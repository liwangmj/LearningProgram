#ifndef TOOLWIDGET_H
#define TOOLWIDGET_H

#include <QWidget>

class toolWidget : public QWidget
{
    Q_OBJECT
public:
    explicit toolWidget(QWidget *parent = 0);
    
signals:
    
public slots:
    
};

#endif // TOOLWIDGET_H
