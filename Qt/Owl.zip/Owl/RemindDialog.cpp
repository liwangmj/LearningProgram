///:
/*****************************************************************************
 **                                                                         **
 **                               .======.                                  **
 **                               | INRI |                                  **
 **                               |      |                                  **
 **                               |      |                                  **
 **                      .========'      '========.                         **
 **                      |   _      xxxx      _   |                         **
 **                      |  /_;-.__ / _\  _.-;_\  |                         **
 **                      |     `-._`'`_/'`.-'     |                         **
 **                      '========.`\   /`========'                         **
 **                               | |  / |                                  **
 **                               |/-.(  |                                  **
 **                               |\_._\ |                                  **
 **                               | \ \`;|                                  **
 **                               |  > |/|                                  **
 **                               | / // |                                  **
 **                               | |//  |                                  **
 **                               | \(\  |                                  **
 **                               |  ``  |                                  **
 **                               |      |                                  **
 **                               |      |                                  **
 **                               |      |                                  **
 **                               |      |                                  **
 **                   \\    _  _\\| \//  |//_   _ \// _                     **
 **                  ^ `^`^ ^`` `^ ^` ``^^`  `^^` `^ `^                     **
 **                                                                         **
 **                    Copyright © 1997-2013 by Tong G.                     **
 **                          ALL RIGHTS RESERVED.                           **
 **                                                                         **
 ****************************************************************************/

#include "RemindDialog.h"
#include <QLabel>
#include <QIcon>
#include <QLayout>
#include <QPushButton>
#include <QCloseEvent>
//.._RemindDialog类实现

    /* 构造函数实现 */
    _RemindDialog::_RemindDialog(QWidget *_Parent)
        : QDialog(_Parent)
        {
        m_IconLabel = new QLabel(
                    QString::fromUtf8("<img src=\":/icons/owl.png\">"));

        m_RemindLabel = new QLabel(QString::fromUtf8("<h1><font color=darkGray>时间到了！"));

        m_OKButton = new QPushButton(QString::fromUtf8("好的"));
        connect(m_OKButton, SIGNAL(clicked()), this, SLOT(accept()));

        QHBoxLayout* _LabelLayout = new QHBoxLayout;
        _LabelLayout->addWidget(m_IconLabel);
        _LabelLayout->addWidget(m_RemindLabel);

        QHBoxLayout* _BottomLayout = new QHBoxLayout;
        _BottomLayout->addStretch();
        _BottomLayout->addWidget(m_OKButton);

        QVBoxLayout* _MainLayout = new QVBoxLayout;
        _MainLayout->addLayout(_LabelLayout);
        _MainLayout->addLayout(_BottomLayout);

        setLayout(_MainLayout);
        setFixedSize(300, 180);
        setWindowIcon(QIcon(":/icons/owl.png"));
        setWindowTitle(QString::fromUtf8("Owl"));
        }

    /* closeEvent()函数重写 */
    void _RemindDialog::closeEvent(QCloseEvent *_Event)
        {
        /* _RemindDialog对话框只接受用户点击m_OKButton按钮发出的关闭事件,
         * 忽略除此之外的所有其他关闭事件 */
        _Event->ignore();
        }

/////////////////////////////////////////////////////////////////////////////

/****************************************************************************
 **                                                                        **
 **      _________                                      _______            **
 **     |___   ___|                                   / ______ \           **
 **         | |     _______   _______   _______      | /      |_|          **
 **         | |    ||     || ||     || ||     ||     | |    _ __           **
 **         | |    ||     || ||     || ||     ||     | |   |__  \          **
 **         | |    ||     || ||     || ||     ||     | \_ _ __| |  _       **
 **         |_|    ||_____|| ||     || ||_____||      \________/  |_|      **
 **                                           ||                           **
 **                                    ||_____||                           **
 **                                                                        **
 ***************************************************************************/
///:~
