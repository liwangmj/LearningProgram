﻿///:
/*****************************************************************************
 **                                                                         **
 **                               .======.                                  **
 **                               | INRI |                                  **
 **                               |      |                                  **
 **                               |      |                                  **
 **                      .========'      '========.                         **
 **                      |   _      xxxx      _   |                         **
 **                      |  /_;-.__ / _\  _.-;_\  |                         **
 **                      |     `-._`'`_/'`.-'     |                         **
 **                      '========.`\   /`========'                         **
 **                               | |  / |                                  **
 **                               |/-.(  |                                  **
 **                               |\_._\ |                                  **
 **                               | \ \`;|                                  **
 **                               |  > |/|                                  **
 **                               | / // |                                  **
 **                               | |//  |                                  **
 **                               | \(\  |                                  **
 **                               |  ``  |                                  **
 **                               |      |                                  **
 **                               |      |                                  **
 **                               |      |                                  **
 **                               |      |                                  **
 **                   \\    _  _\\| \//  |//_   _ \// _                     **
 **                  ^ `^`^ ^`` `^ ^` ``^^`  `^^` `^ `^                     **
 **                                                                         **
 **                    Copyright © 1997-2013 by Tong G.                     **
 **                          ALL RIGHTS RESERVED.                           **
 **                                                                         **
 ****************************************************************************/

#include "MainWindow.h"
#include "Timer.h"
#include <QApplication>
#include <QGroupBox>
#include <QString>
#include <QLayout>
#include <QToolButton>
#include <QIcon>
#include <QMessageBox>
//.._MainWindow类实现

    /* 构造函数实现 */
    _MainWindow::_MainWindow(QWidget *_Parent)
        : QWidget(_Parent)
        {
        _CreateTimerGroupBox();
        _CreateAllButtons();

        QHBoxLayout* _ButtonsLayout = new QHBoxLayout;
        _ButtonsLayout->addStretch();
        _ButtonsLayout->addWidget(m_SetRingButton);
        _ButtonsLayout->addWidget(m_ReportBugButton);
        _ButtonsLayout->addWidget(m_HelpButton);
        _ButtonsLayout->addWidget(m_AboutQt);
        _ButtonsLayout->addStretch();

        QGridLayout* _MainLayout = new QGridLayout;
        _MainLayout->addWidget(m_TimerGroupBox, 0, 0);
        _MainLayout->addLayout(_ButtonsLayout, 1, 0);

        setLayout(_MainLayout);
        setWindowTitle(tr("Owl"));
        setWindowIcon(QIcon(":/icons/owl.png"));
        setFixedSize(QSize(300, 350));
        }

    /////////////////////////////////////////////////////////////////////////
    //..protected部分

    //..protected slots
    /* _HelpButtonClicked()槽实现 */
    void _MainWindow::_HelpButtonClicked()
        {
        QMessageBox::about(this, QString::fromUtf8("关于Owl"),
             tr("<h1>Owl 0.7</h1>"
             "<p><h4>Beta</h4>"
             "<p>Copyright &copy; 1997-2013 Tong G. "
             "<p>此程序不遵循任何许可证发布。"
             "<p>欢迎任何个人或组织使用、修改、复制、再分发该程序的代码。"
             ));
        }

    /* _ReportBugButtonClicked()槽实现 */
    void _MainWindow::_ReportBugButtonClicekd()
        {
        QMessageBox::information(this, QString::fromUtf8("报告Bug"),
                                 QString::fromUtf8("<h3>发现了Bug？</h3>发邮件通知作者："
                                                   "<p>is.gt.forever@gmail.com"
                                                   "<p>QQ：842811465"
                                                   "<p><font color = red>也欢迎自己修改源代码然后再分发。"
                                                   ));
        }

    /* _CreateTimerGroupBox()函数实现 */
    void _MainWindow::_CreateTimerGroupBox()
        {
        m_TimerGroupBox = new QGroupBox(QString::fromUtf8(""));
        m_Timer = new _Timer(this);

        QGridLayout* _TimerLayout = new QGridLayout;
        _TimerLayout->addWidget(m_Timer, 0, 0);

        m_TimerGroupBox->setLayout(_TimerLayout);
        }

    /* _CreateAllButtons()函数实现 */
    void _MainWindow::_CreateAllButtons()
        {
        m_SetRingButton = new QToolButton;
        m_SetRingButton->setAutoRaise(true);
        m_SetRingButton->setText(tr("设置响铃音乐"));
        m_SetRingButton->setIcon(QIcon(":/icons/setmusic.png"));
        m_SetRingButton->setToolTip(QString::fromUtf8("设置响铃音乐"));
        connect(m_SetRingButton, SIGNAL(clicked()), m_Timer, SLOT(_SetRingButtonClicked()));

        m_HelpButton = new QToolButton;
        m_HelpButton->setAutoRaise(true);
        m_HelpButton->setText(tr("帮助"));
        m_HelpButton->setIcon(QIcon(":/icons/help.png"));
        m_HelpButton->setToolTip(QString::fromUtf8("关于Owl"));
        connect(m_HelpButton, SIGNAL(clicked()), this, SLOT(_HelpButtonClicked()));

        m_ReportBugButton = new QToolButton;
        m_ReportBugButton->setAutoRaise(true);
        m_ReportBugButton->setText(tr("报告Bug"));
        m_ReportBugButton->setIcon(QIcon(":/icons/reportbug.png"));
        m_ReportBugButton->setToolTip(QString::fromUtf8("报告Bug"));
        connect(m_ReportBugButton, SIGNAL(clicked()), this, SLOT(_ReportBugButtonClicekd()));

        m_AboutQt = new QToolButton;
        m_AboutQt->setAutoRaise(true);
        m_AboutQt->setIcon(QIcon(":/icons/Qt.png"));
        m_AboutQt->setText(tr("关于Qt"));
        m_AboutQt->setToolTip(QString::fromUtf8("关于Qt"));
        connect(m_AboutQt, SIGNAL(clicked()), qApp, SLOT(aboutQt()));
        }

/////////////////////////////////////////////////////////////////////////////

/****************************************************************************
 **                                                                        **
 **      _________                                      _______            **
 **     |___   ___|                                   / ______ \           **
 **         | |     _______   _______   _______      | /      |_|          **
 **         | |    ||     || ||     || ||     ||     | |    _ __           **
 **         | |    ||     || ||     || ||     ||     | |   |__  \          **
 **         | |    ||     || ||     || ||     ||     | \_ _ __| |  _       **
 **         |_|    ||_____|| ||     || ||_____||      \________/  |_|      **
 **                                           ||                           **
 **                                    ||_____||                           **
 **                                                                        **
 ***************************************************************************/
///:~
