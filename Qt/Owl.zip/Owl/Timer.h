﻿///:
/*****************************************************************************
 **                                                                         **
 **                               .======.                                  **
 **                               | INRI |                                  **
 **                               |      |                                  **
 **                               |      |                                  **
 **                      .========'      '========.                         **
 **                      |   _      xxxx      _   |                         **
 **                      |  /_;-.__ / _\  _.-;_\  |                         **
 **                      |     `-._`'`_/'`.-'     |                         **
 **                      '========.`\   /`========'                         **
 **                               | |  / |                                  **
 **                               |/-.(  |                                  **
 **                               |\_._\ |                                  **
 **                               | \ \`;|                                  **
 **                               |  > |/|                                  **
 **                               | / // |                                  **
 **                               | |//  |                                  **
 **                               | \(\  |                                  **
 **                               |  ``  |                                  **
 **                               |      |                                  **
 **                               |      |                                  **
 **                               |      |                                  **
 **                               |      |                                  **
 **                   \\    _  _\\| \//  |//_   _ \// _                     **
 **                  ^ `^`^ ^`` `^ ^` ``^^`  `^^` `^ `^                     **
 **                                                                         **
 **                    Copyright © 1997-2013 by Tong G.                     **
 **                          ALL RIGHTS RESERVED.                           **
 **                                                                         **
 ****************************************************************************/

#pragma once
#include <QWidget>
#include <QDateTime>

class QDateTime;
class QTimer;
class QSound;
class QString;
class _AskDialog;
class _RemindDialog;

class _Timer : public QWidget
    {
    Q_OBJECT

public:
    _Timer(QWidget* _Parent = NULL);    // DONE

    void _SetDuration(int _Secs);   // 设置持续时间   // DONE
    int  _Duration() const;         // 返回持续时间   // DONE
    void _Draw(QPainter* _Painter);

signals:
    void _Timeout();

public slots:
    void _SetRingButtonClicked();    // DONE

protected slots:
    void _PlayRing();   // DONE
    void _RemindYou();  // DONE
    void closeEvent(QCloseEvent *_Event);  // DONE
    void _WriteSettings();  // DONE
    void _ReadSettings();   // DONE

protected:
    void paintEvent(QPaintEvent *_Event);   // DONE
    void mousePressEvent(QMouseEvent *_Event);  // DONE
    void wheelEvent(QWheelEvent *_Event);   // DONE

    void _TimerRoll(QEvent* _Event);    // DONE

    QDateTime m_FinishTime;
    QTimer*   m_UpdateTimer;    // 用于每隔5秒刷新一次窗口部件
    QTimer*   m_FinishTimer;
    QSound*   m_Player;
    QString   m_SoundFileName;

    _AskDialog* m_AskWhenBeginDialog;
//    _RemindDialog* m_RemindYouDialog;
    };

/////////////////////////////////////////////////////////////////////////////

/****************************************************************************
 **                                                                        **
 **      _________                                      _______            **
 **     |___   ___|                                   / ______ \           **
 **         | |     _______   _______   _______      | /      |_|          **
 **         | |    ||     || ||     || ||     ||     | |    _ __           **
 **         | |    ||     || ||     || ||     ||     | |   |__  \          **
 **         | |    ||     || ||     || ||     ||     | \_ _ __| |  _       **
 **         |_|    ||_____|| ||     || ||_____||      \________/  |_|      **
 **                                           ||                           **
 **                                    ||_____||                           **
 **                                                                        **
 ***************************************************************************/
///:~
