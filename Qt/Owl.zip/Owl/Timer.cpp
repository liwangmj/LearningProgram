﻿///:
/*****************************************************************************
 **                                                                         **
 **                               .======.                                  **
 **                               | INRI |                                  **
 **                               |      |                                  **
 **                               |      |                                  **
 **                      .========'      '========.                         **
 **                      |   _      xxxx      _   |                         **
 **                      |  /_;-.__ / _\  _.-;_\  |                         **
 **                      |     `-._`'`_/'`.-'     |                         **
 **                      '========.`\   /`========'                         **
 **                               | |  / |                                  **
 **                               |/-.(  |                                  **
 **                               |\_._\ |                                  **
 **                               | \ \`;|                                  **
 **                               |  > |/|                                  **
 **                               | / // |                                  **
 **                               | |//  |                                  **
 **                               | \(\  |                                  **
 **                               |  ``  |                                  **
 **                               |      |                                  **
 **                               |      |                                  **
 **                               |      |                                  **
 **                               |      |                                  **
 **                   \\    _  _\\| \//  |//_   _ \// _                     **
 **                  ^ `^`^ ^`` `^ ^` ``^^`  `^^` `^ `^                     **
 **                                                                         **
 **                    Copyright © 1997-2013 by Tong G.                     **
 **                          ALL RIGHTS RESERVED.                           **
 **                                                                         **
 ****************************************************************************/

#include "Timer.h"
#include <AskDialog.h>
#include <RemindDialog.h>

#include <cmath>
#include <QApplication>
#include <QDateTime>
#include <QTimer>
#include <QPoint>
#include <QPointF>
#include <QFont>
#include <QPen>
#include <QBrush>
#include <QPainter>
#include <QMouseEvent>
#include <QPaintEvent>
#include <QWheelEvent>
#include <QIcon>
#include <QFileDialog>
#include <QSound>
#include <QCloseEvent>
#include <QSettings>

//////////////////////////////////////////////////////////////////////////////

/* 控制定时器外观的常量 */
const double g_Pi = 3.14159265359;
const double g_DegreesPerMinute = 7.0;  // 没分钟旋转的度数
const double g_DegreesPerSecond = g_DegreesPerMinute / 60;  // 每秒钟旋转的度数
const int    g_MaxMinutes = 45;
const int    g_MaxSeconds = g_MaxMinutes * 60;
const int    g_UpdateInterval = 5;  // 每隔5秒进行刷新

//////////////////////////////////////////////////////////////////////////////

//.._Timer类实现

    /* 构造函数实现 */
    _Timer::_Timer(QWidget *_Parent)
        : QWidget(_Parent)
        {
        m_FinishTime = QDateTime::currentDateTime();
        m_UpdateTimer = new QTimer(this);
        connect(m_UpdateTimer, SIGNAL(timeout()), this, SLOT(update()));

        m_FinishTimer = new QTimer(this);
        m_FinishTimer->setSingleShot(true); // m_FinishTimer只需被执行一次
        connect(m_FinishTimer, SIGNAL(timeout()), this, SIGNAL(_Timeout()));

        _ReadSettings();
                                            /* 当定时器停止运行时停止更新窗口部件 */
        connect(m_FinishTimer, SIGNAL(timeout()), m_UpdateTimer, SLOT(stop()));
        connect(m_FinishTimer, SIGNAL(timeout()), this, SLOT(_PlayRing()));
        connect(m_FinishTimer, SIGNAL(timeout()), this, SLOT(_RemindYou()));

        QFont _Font;
        _Font.setPointSize(8);
        setFont(_Font);

        m_AskWhenBeginDialog = new _AskDialog(this);

        if (m_SoundFileName.isEmpty())
            {
            if (m_AskWhenBeginDialog->exec())
                _SetRingButtonClicked();
            }
        }

    /* _SetDuration()函数实现
     * 该函数用于设置定时器持续的时间为给定的秒数
     */
    void _Timer::_SetDuration(int _Secs)
        {
    #if 0
        if (_Secs < 0)
            _Secs = 0;
        else if (_Secs > g_MaxSeconds)
            _Secs = g_MaxSeconds
    #endif  /* 使用qBound()代替 */
        _Secs = qBound(0, _Secs, g_MaxSeconds);

        /* 把定时器的结束时间设为在当前的系统时间上加上给定的间隔时间 */
        m_FinishTime = QDateTime::currentDateTime().addSecs(_Secs);

        if (_Secs > 0)
            {
            m_UpdateTimer->start(g_UpdateInterval * 1000);
            m_FinishTimer->start(_Secs * 1000);
            } else
                {
                m_UpdateTimer->stop();
                m_FinishTimer->stop();
                }
        update();   /* 用新的间隔时间重绘窗口部件 */
        }

    /* _Duration()函数实现
     * 该函数返回定时器完成前剩余的秒数
     */
    int _Timer::_Duration() const
        {
        /* 使用完成时间减去当前系统时间获得定时器中设置的间隔时间 */
        int _Secs = QDateTime::currentDateTime().secsTo(m_FinishTime);

        if (_Secs < 0 /* 如果定时器未激活... */)
            _Secs = 0;

        return _Secs;
        }

    /* _Draw()函数实现 */
    void _Timer::_Draw(QPainter *_Painter)
        {
        static const int _Triangle[3][2] =  /* 三角形 */
            {
            {-2, -49}, {+2, -49}, {0, -47}
            };

        QPen _ThickPen(QPen(Qt::black, 1.0, Qt::SolidLine, Qt::RoundCap));// 创建一个细画笔
        QPen _ThinPen(QPen(Qt::black, 0.5, Qt::SolidLine, Qt::RoundCap)); // 创建一个细画笔
        QColor _NiceBlue(150, 150, 200);

        _Painter->setPen(_ThinPen);
        _Painter->setBrush(palette().foreground());
        _Painter->save();
        _Painter->setBrush(QBrush(Qt::yellow, Qt::SolidPattern));
        /* 在窗口部件顶部位置绘制一个三角形 */
        _Painter->drawPolygon(QPolygon(3, &_Triangle[0][0]));
        _Painter->restore();

        /* 使用椎型渐变填充
         * 椎型中心点位于(0,0), 角度是-90度 */
        QConicalGradient _ConeGradient(0, 0, -90.0);
        _ConeGradient.setColorAt(0.0, Qt::darkGray);
        _ConeGradient.setColorAt(0.2, _NiceBlue);
        _ConeGradient.setColorAt(0.5, Qt::white);
        _ConeGradient.setColorAt(1.0, Qt::darkGray);

        _Painter->setBrush(_ConeGradient);
        _Painter->setPen(Qt::lightGray);
        _Painter->drawEllipse(-46, -46, 92, 92); /* 在(-46,-46)位置绘制一个直径为92的圆形
                                                  * 该圆形作为定时器外部的圆形
                                                  * 该圆形内部使用椎型渐变色填充
                                                  */
        /* 使用辐射渐变色填充
         * 渐变中心和焦点都在(0,0), 渐变的半径是20 */
        QRadialGradient _HaloGradient(0, 0, 20, 0, 0);
        _HaloGradient.setColorAt(0.0, Qt::lightGray);
        _HaloGradient.setColorAt(0.8, Qt::darkGray);
        _HaloGradient.setColorAt(0.9, Qt::white);
        _HaloGradient.setColorAt(1.0, Qt::darkGray);

        _Painter->setPen(Qt::NoPen);
        _Painter->setBrush(_HaloGradient);
        _Painter->drawEllipse(-20, -20, 40, 40); /* 在(-20, -20)位置绘制一个直径为40的圆形
                                                  * 该圆作为定时器内部的圆形
                                                  * 该圆形内部使用辐射渐变色填充
                                                  */
        /* 使用线性渐变色填充 */
        QLinearGradient _KnobGradient(-7, -25, 7, -25);
        _KnobGradient.setColorAt(0.0, Qt::black);
        _KnobGradient.setColorAt(0.2, _NiceBlue);
        _KnobGradient.setColorAt(0.3, Qt::lightGray);
        _KnobGradient.setColorAt(0.8, Qt::white);
        _KnobGradient.setColorAt(1.0, Qt::darkGray);

        _Painter->rotate(_Duration() * g_DegreesPerSecond); // 旋转绘图器的坐标系统
        _Painter->setBrush(_KnobGradient);
        _Painter->setPen(Qt::darkGray);
        _Painter->drawRoundRect(-7, -25, 14, 50, 90, 50); /* 绘制矩形旋钮,
                                                             * 使用线性渐变色
                                                             */
        /* 在表盘上绘制时间刻度 */
        for (int _Index = 0; _Index <= g_MaxMinutes; ++_Index)
            {
            _Painter->save();
            _Painter->rotate(-_Index * g_DegreesPerMinute);

            if (_Index % 5 == 0 /* 如果该刻度是5的倍数... */)
                {
                if (_Index == 0)
                    _Painter->setPen(QPen(Qt::darkRed, 1.5, Qt::SolidLine, Qt::RoundCap));
                else
                    _Painter->setPen(_ThickPen);    /* 使用粗笔绘制5的倍数的时间刻度 */

                _Painter->drawLine(0, -41, 0, -44);
                _Painter->save();
                _Painter->setPen(_ThickPen);
                _Painter->drawText(-15, -41, 30, 30,
                                   Qt::AlignHCenter | Qt::AlignTop,
                                   QString::number(_Index));
                _Painter->restore();
                }
            else
                {
                _Painter->setPen(_ThinPen); /* 使用细笔绘制不是5的倍数的时间刻度 */
                _Painter->drawLine(0, -42, 0, -44);
                }

            _Painter->restore();
            }
        }

    /////////////////////////////////////////////////////////////////////////
    //..protected部分

    /* _PlayRing()函数实现 */
    void _Timer::_PlayRing()
        {
        if (!m_SoundFileName.isEmpty())
            {
            m_Player = new QSound(m_SoundFileName);
            if (m_Player->isFinished())
                {
                m_Player->setLoops(10);
                m_Player->play();
                }
            }
        }

    /* _RemindYou()槽实现 */
    void _Timer::_RemindYou()
        {
        _RemindDialog _RemindYouDialog;

        if (_RemindYouDialog.exec())
            m_Player->stop();
        }

    /* closeEvet()函数重写 */
    void _Timer::closeEvent(QCloseEvent *_Event)
        {
        _WriteSettings();
        _Event->accept();
        }

    /* _WriteSettings()函数实现 */
    void _Timer::_WriteSettings()
        {
        QSettings _Settings("Tong G.", "Owl");

        _Settings.setValue("Sound File Name", m_SoundFileName);
        }

    /* _ReadSettings()函数实现 */
    void _Timer::_ReadSettings()
        {
        QSettings _Settings("Tong G.", "Owl");

        m_SoundFileName = _Settings.value("Sound File Name").toString();
        }

    /* paintEvent()函数重写 */
    void _Timer::paintEvent(QPaintEvent */*_Event*/)
        {
        QPainter _Painter(this);
        _Painter.setRenderHint(QPainter::Antialiasing, true);

        int _Side = qMin(width(), height());

        _Painter.setViewport((width() - _Side) / 2, (height() - _Side) / 2,
                             _Side, _Side);
        _Painter.setWindow(-50, -50, 100, 100);

        _Draw(&_Painter);
        }

    /* mousePressEvent()函数重写 */
    void _Timer::mousePressEvent(QMouseEvent *_Event)
        {
        _TimerRoll(_Event);
        }

    /* wheelEvent()函数重写 */
    void _Timer::wheelEvent(QWheelEvent *_Event)
        {
        _TimerRoll(_Event);
        }

    /* _TimerRoll()函数实现 */
    void _Timer::_TimerRoll(QEvent *_Event)
        {
        if (_Event->type() == QEvent::MouseButtonPress)
            {
            QMouseEvent* _theEvent = dynamic_cast<QMouseEvent *>(_Event);
                {
                if (_theEvent->button() == Qt::LeftButton)
                    {
                    QPointF _Point = _theEvent->pos() - rect().center();

                    /* 使用该公式计算出离用户点击鼠标位置最近的刻度 */
                    double _Theta = std::atan2(-_Point.x(),
                                               -_Point.y()) * 180.0 / g_Pi;

                    /* 使用_Theta来设置新的持续时间: 用户点过的刻度被移到定时器最上端 */
                    _SetDuration(_Duration()
                                 + int(_Theta / g_DegreesPerSecond));
                    }
                }
            }
        else if (_Event->type() == QEvent::Wheel)
            {
            QWheelEvent* _theEvent = dynamic_cast<QWheelEvent *>(_Event);
            QPointF _Point = _theEvent->pos() - rect().center();
            double _Theta = std::atan2(-_Point.x(),
                                       -_Point.y()) * 180.0 / g_Pi;
            _SetDuration(_Duration()
                         + int(_Theta / g_DegreesPerSecond));
            }

        update();
        }

    /* _SetRingButtonClicked()槽实现 */
    void _Timer::_SetRingButtonClicked()
        {
        m_SoundFileName =
        QFileDialog::getOpenFileName(this,
                                     QString::fromUtf8("选择wav格式的音频作为闹铃"),
                                     ".", ".wav");

        QSettings _Settings("Tong G.", "Owl");
        _Settings.setValue("Sound File Name", m_SoundFileName);
        }

/////////////////////////////////////////////////////////////////////////////

/****************************************************************************
 **                                                                        **
 **      _________                                      _______            **
 **     |___   ___|                                   / ______ \           **
 **         | |     _______   _______   _______      | /      |_|          **
 **         | |    ||     || ||     || ||     ||     | |    _ __           **
 **         | |    ||     || ||     || ||     ||     | |   |__  \          **
 **         | |    ||     || ||     || ||     ||     | \_ _ __| |  _       **
 **         |_|    ||_____|| ||     || ||_____||      \________/  |_|      **
 **                                           ||                           **
 **                                    ||_____||                           **
 **                                                                        **
 ***************************************************************************/
///:~
