///:
/*****************************************************************************
 **                                                                         **
 **                               .======.                                  **
 **                               | INRI |                                  **
 **                               |      |                                  **
 **                               |      |                                  **
 **                      .========'      '========.                         **
 **                      |   _      xxxx      _   |                         **
 **                      |  /_;-.__ / _\  _.-;_\  |                         **
 **                      |     `-._`'`_/'`.-'     |                         **
 **                      '========.`\   /`========'                         **
 **                               | |  / |                                  **
 **                               |/-.(  |                                  **
 **                               |\_._\ |                                  **
 **                               | \ \`;|                                  **
 **                               |  > |/|                                  **
 **                               | / // |                                  **
 **                               | |//  |                                  **
 **                               | \(\  |                                  **
 **                               |  ``  |                                  **
 **                               |      |                                  **
 **                               |      |                                  **
 **                               |      |                                  **
 **                               |      |                                  **
 **                   \\    _  _\\| \//  |//_   _ \// _                     **
 **                  ^ `^`^ ^`` `^ ^` ``^^`  `^^` `^ `^                     **
 **                                                                         **
 **                    Copyright © 1997-2013 by Tong G.                     **
 **                          ALL RIGHTS RESERVED.                           **
 **                                                                         **
 ****************************************************************************/

#include "AskDialog.h"

#include <QPushButton>
#include <QLabel>
#include <QString>
#include <QLayout>
#include <QIcon>
#include <QUrl>
#include <QDesktopServices>
//.._AskDialog类实现

    /* 构造函数实现 */
    _AskDialog::_AskDialog(QWidget *_Parent)
        : QDialog(_Parent)
        {
        m_IconLabel = new QLabel("<img src=\":/icons/owl.png\">");
        m_AskLabel = new QLabel(QString::fromUtf8("<h3>您还没有选择任何音频作为闹铃，是否选择一个？</h3>"
                                                  "<p><b><font color=red>*注意</font></b>  "
                                                  "<li><b>①</b> Owl只支持wav格式的音频作为闹铃。"
                                                  "<p><li><b>②</b> 如果手头有别的格式的音频，可以使用音频格式转换工具进行转换。"
                                                  "<p><li><b>③</b> Owl会记住您选择的音频，下次启动时会自动使用您选择的音频作为闹铃。"));

        m_SelectButton = new QPushButton(QString::fromUtf8("现在选择(&S)"));
        connect(m_SelectButton, SIGNAL(clicked()),
                this, SLOT(accept()));

        m_RejectButton = new QPushButton(QString::fromUtf8("以后再说(&R)"));
        connect(m_RejectButton, SIGNAL(clicked()), this, SLOT(reject()));

        QHBoxLayout* _TopLayout = new QHBoxLayout;
        _TopLayout->addWidget(m_IconLabel);
        _TopLayout->addWidget(m_AskLabel);

        QHBoxLayout* _BottomLayout = new QHBoxLayout;
        _BottomLayout->addStretch();
        _BottomLayout->addWidget(m_SelectButton);
        _BottomLayout->addWidget(m_RejectButton);

        QVBoxLayout* _MainLayout = new QVBoxLayout;
        _MainLayout->addLayout(_TopLayout);
        _MainLayout->addLayout(_BottomLayout);

        setLayout(_MainLayout);

        setFixedSize(sizeHint());
        setWindowTitle(QString::fromUtf8("Owl"));
        setWindowIcon(QIcon(":/icons/owl.png"));
        }

/////////////////////////////////////////////////////////////////////////////

/****************************************************************************
 **                                                                        **
 **      _________                                      _______            **
 **     |___   ___|                                   / ______ \           **
 **         | |     _______   _______   _______      | /      |_|          **
 **         | |    ||     || ||     || ||     ||     | |    _ __           **
 **         | |    ||     || ||     || ||     ||     | |   |__  \          **
 **         | |    ||     || ||     || ||     ||     | \_ _ __| |  _       **
 **         |_|    ||_____|| ||     || ||_____||      \________/  |_|      **
 **                                           ||                           **
 **                                    ||_____||                           **
 **                                                                        **
 ***************************************************************************/
///:~

