#include "mainwindow.h"
#include <QImage>
#include "ui_mainwindow.h"
#include <QHostInfo>
QString MyIp;
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    /*��ȡ��������̬IP
    QHostInfo host = QHostInfo::fromName(QHostInfo::localHostName());

    foreach (QHostAddress address, host.addresses())

    MyIp = address.toString();
    */
    /*����socketserver*/
      ui->setupUi(this);
    /*��ʾ������̬IP
    ui->lb_myIP->setText(MyIp);
    */
      internetOP.tcpServer=new QTcpServer(this);//--tcp
      internetOP.tcpServer->listen(QHostAddress::Any, 5234);//listen(QHostAddress::Any, 5234);
      connect(internetOP.tcpServer, SIGNAL(newConnection()),this, SLOT(haveConnect()));
  /*    internetOP.tcpSocket=new QTcpSocket();
      internetOP.tcpSocket->close();
      */
}

MainWindow::~MainWindow()
{
    delete ui;
}
void MainWindow::haveConnect()
{
 //   ui->label->setText("some one");
    internetOP.tcpSocket = internetOP.tcpServer->nextPendingConnection();//build a socket for this time commuincation
    QString ClientIp = internetOP.tcpSocket->peerAddress().toString();//show note"some one coming"
    ui->lb_ClientIp->setText(ClientIp);
    connect(internetOP.tcpSocket,SIGNAL(readyRead()),this,SLOT(getTcpMessage()));//the under line must be write before tcpsocker instantiation
}
void MainWindow::getTcpMessage()
{

    QImage getpicture;

    getpicture = internetOP.TcpSocketReadQImage();
 //   getpicture.save("hellp.png");
    ui->label->setPixmap(QPixmap::fromImage(getpicture));  // ��ͼƬ��ʾ��label��
    internetOP.tcpSocket->close();

   // ui->label->setText(tem);
    /*��ȡ����
    ui->label->setText("reading");
    QStringList s3c2410ClientList;
    QString tem;
    s3c2410ClientList<<internetOP.TcpSocketRead();

    internetOP.tcpSocket->close();

    tem = s3c2410ClientList.at(0);
    ui->label->setText(tem);
    */
}
void MainWindow::on_pushButton_clicked()
{
/*
    QStringList txt;

    txt<<ui->lineEdit->text();//���÷�������

    internetOP.tcpSocket->write(internetOP.WriteQByteArray(txt));//����
    internetOP.tcpSocket->close();//�ر�
    */
}
