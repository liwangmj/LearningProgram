#include "interop.h"
#include "QStringList"
#include <QDataStream>
interOP::interOP()
{
 //    tcpSocket = new QTcpSocket(this);
}

void interOP::TcpSocketSend(QByteArray SendBlock)
{
    tcpSocket->write(SendBlock);
}
void interOP::TcpSocketClose()
{
    tcpSocket->close();
}
QStringList interOP::TcpSocketRead()
{
    QStringList l;
    int n;
    block.resize(tcpSocket->size());
    tcpSocket->read(block.data(),block.size());
    n = block.size();
    QDataStream in(&block,QIODevice::ReadOnly);
    in.setVersion(QDataStream::Qt_4_6);
    in>>l;
    return l;
}
QImage interOP::TcpSocketReadQImage()
{
    QImage l;
    int n;
    block.resize(tcpSocket->size());
    tcpSocket->read(block.data(),block.size());
    n = block.size();
    QDataStream in(&block,QIODevice::ReadOnly);
    in.setVersion(QDataStream::Qt_4_6);
    in>>l;
    l.save("hhhh.png");
    return l;
}
QByteArray interOP::WriteQByteArray(QStringList txtList)
{
    QDataStream out(&block, QIODevice::WriteOnly);
        out.setVersion(QDataStream::Qt_4_6);
            out  << txtList;

        return block;
}
void interOP::TcpConnect(QString ip, int port)
{
    tcpSocket->connectToHost(QHostAddress(ip),port);
}
void interOP::setServerConnect(QString serveraddr, int tcpport)
{
    ServerADDr=serveraddr;
    ServerTcpPort=tcpport;
}
QString interOP::getServerAddr()
{
    return ServerADDr;
}
int interOP::getServerPort()
{
    return ServerTcpPort;
}
