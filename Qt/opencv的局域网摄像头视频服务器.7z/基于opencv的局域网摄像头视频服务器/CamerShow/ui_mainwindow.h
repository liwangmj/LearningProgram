/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created: Fri Oct 26 18:55:06 2012
**      by: Qt User Interface Compiler version 4.6.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QMainWindow>
#include <QtGui/QMenuBar>
#include <QtGui/QPushButton>
#include <QtGui/QStatusBar>
#include <QtGui/QToolBar>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QLabel *label;
    QPushButton *open;
    QPushButton *pic;
    QPushButton *closeCam;
    QLabel *label_2;
    QLineEdit *le_hight;
    QLineEdit *le_width;
    QLabel *label_3;
    QLabel *label_4;
    QLineEdit *le_timeSecond;
    QLabel *label_5;
    QLineEdit *le_serverIp;
    QLabel *label_6;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(800, 800);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        label = new QLabel(centralWidget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(20, 10, 101, 61));
        open = new QPushButton(centralWidget);
        open->setObjectName(QString::fromUtf8("open"));
        open->setGeometry(QRect(20, 450, 75, 23));
        pic = new QPushButton(centralWidget);
        pic->setObjectName(QString::fromUtf8("pic"));
        pic->setGeometry(QRect(20, 480, 75, 23));
        closeCam = new QPushButton(centralWidget);
        closeCam->setObjectName(QString::fromUtf8("closeCam"));
        closeCam->setGeometry(QRect(20, 510, 75, 23));
        label_2 = new QLabel(centralWidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(230, 80, 451, 451));
        le_hight = new QLineEdit(centralWidget);
        le_hight->setObjectName(QString::fromUtf8("le_hight"));
        le_hight->setGeometry(QRect(30, 350, 61, 21));
        le_width = new QLineEdit(centralWidget);
        le_width->setObjectName(QString::fromUtf8("le_width"));
        le_width->setGeometry(QRect(30, 400, 61, 21));
        label_3 = new QLabel(centralWidget);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(30, 320, 54, 12));
        label_4 = new QLabel(centralWidget);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(30, 380, 54, 12));
        le_timeSecond = new QLineEdit(centralWidget);
        le_timeSecond->setObjectName(QString::fromUtf8("le_timeSecond"));
        le_timeSecond->setGeometry(QRect(30, 290, 61, 21));
        label_5 = new QLabel(centralWidget);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(30, 260, 71, 20));
        le_serverIp = new QLineEdit(centralWidget);
        le_serverIp->setObjectName(QString::fromUtf8("le_serverIp"));
        le_serverIp->setGeometry(QRect(30, 240, 171, 20));
        label_6 = new QLabel(centralWidget);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(30, 220, 54, 12));
        MainWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 800, 19));
        MainWindow->setMenuBar(menuBar);
        mainToolBar = new QToolBar(MainWindow);
        mainToolBar->setObjectName(QString::fromUtf8("mainToolBar"));
        MainWindow->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        MainWindow->setStatusBar(statusBar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("MainWindow", "TextLabel", 0, QApplication::UnicodeUTF8));
        open->setText(QApplication::translate("MainWindow", "open", 0, QApplication::UnicodeUTF8));
        pic->setText(QApplication::translate("MainWindow", "pic", 0, QApplication::UnicodeUTF8));
        closeCam->setText(QApplication::translate("MainWindow", "closeCam", 0, QApplication::UnicodeUTF8));
        label_2->setText(QApplication::translate("MainWindow", "TextLabel", 0, QApplication::UnicodeUTF8));
        le_hight->setText(QApplication::translate("MainWindow", "64", 0, QApplication::UnicodeUTF8));
        le_width->setText(QApplication::translate("MainWindow", "64", 0, QApplication::UnicodeUTF8));
        label_3->setText(QApplication::translate("MainWindow", "hight", 0, QApplication::UnicodeUTF8));
        label_4->setText(QApplication::translate("MainWindow", "width", 0, QApplication::UnicodeUTF8));
        le_timeSecond->setText(QApplication::translate("MainWindow", "33", 0, QApplication::UnicodeUTF8));
        label_5->setText(QApplication::translate("MainWindow", "timer second", 0, QApplication::UnicodeUTF8));
        label_6->setText(QApplication::translate("MainWindow", "server iP", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
