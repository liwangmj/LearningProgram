#ifndef INTEROP_H
#define INTEROP_H
#include <QImage>
#include <QObject>
#include <QTcpServer>
#include <QTcpSocket>

class interOP : public QObject
{
public:
    interOP();

    QTcpSocket *tcpSocket;
    QTcpSocket *tcpSocket2;

    QTcpServer *tcpServer;

    QTcpServer *TcpServer;//Inter Communication........

    void TcpSocketSend(QByteArray SendBlock);//tcp control
    QStringList TcpSocketRead();
    void TcpConnect(QString ip,int port);
    void TcpSocketClose();

    void setServerConnect(QString serveraddr,int tcpport);//set and get nature
    QByteArray WriteQByteArray(QStringList txtList);
    QByteArray WriteQByteArray2(QImage sendPicture);//����ͼƬǰ��׼��
    QString getServerAddr();
    int getServerPort();
    QByteArray block;
private:
        QString ServerADDr;
        int ServerTcpPort;
};

#endif // INTEROP_H
