#include "setting.h"

setting::setting()
{
}
