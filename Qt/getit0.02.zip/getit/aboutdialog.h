#ifndef ABOUTDIALOG_H
#define ABOUTDIALOG_H

#include <QDialog>

class AboutDialog : public QDialog
{
public:
    AboutDialog(QWidget *parent);
};

#endif // ABOUTDIALOG_H
