#ifndef SETTING_H
#define SETTING_H

#include <QSetting>

class setting : public QSetting
{
public:
    setting();
};

#endif // SETTING_H
