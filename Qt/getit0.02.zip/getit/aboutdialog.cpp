#include "aboutdialog.h"

AboutDialog::AboutDialog(QWidget *parent): QDialog(parent)
{
}
