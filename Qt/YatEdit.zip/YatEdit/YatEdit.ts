<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="en" sourcelanguage="zh">
<context>
    <name>ConfigDialog</name>
    <message utf8="true">
        <location filename="ConfigDialog.cpp" line="37"/>
        <source>关闭</source>
        <translation type="unfinished">Close</translation>
    </message>
    <message utf8="true">
        <location filename="ConfigDialog.cpp" line="38"/>
        <source>确定</source>
        <translation type="unfinished">Ok</translation>
    </message>
    <message utf8="true">
        <location filename="ConfigDialog.cpp" line="63"/>
        <source>配置首选项</source>
        <translation type="unfinished">Preferences</translation>
    </message>
    <message utf8="true">
        <location filename="ConfigDialog.cpp" line="71"/>
        <source>编辑器</source>
        <translation type="unfinished">Editor</translation>
    </message>
    <message utf8="true">
        <location filename="ConfigDialog.cpp" line="77"/>
        <source>视图</source>
        <translation type="unfinished">Views</translation>
    </message>
    <message utf8="true">
        <location filename="ConfigDialog.cpp" line="83"/>
        <source>查看</source>
        <translation type="unfinished">Look</translation>
    </message>
</context>
<context>
    <name>EditArea</name>
    <message>
        <location filename="EditArea.cpp" line="205"/>
        <location filename="EditArea.cpp" line="306"/>
        <source>~newfile~</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="EditArea.cpp" line="290"/>
        <source>Monospace</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="EditArea.cpp" line="310"/>
        <source>YatEdit</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="EditArea.cpp" line="311"/>
        <source>不能保存文件 %1:
%2.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EditToolBars</name>
    <message utf8="true">
        <location filename="ToolBars.cpp" line="56"/>
        <source>复制</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="ToolBars.cpp" line="57"/>
        <source>复制选定文本</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="ToolBars.cpp" line="59"/>
        <source>粘贴</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="ToolBars.cpp" line="60"/>
        <source>在当前位置粘贴</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="ToolBars.cpp" line="62"/>
        <source>剪贴</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="ToolBars.cpp" line="63"/>
        <source>剪切当前文本</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SearchDialog</name>
    <message utf8="true">
        <location filename="SearchDialog.cpp" line="14"/>
        <source>搜索</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="SearchDialog.cpp" line="19"/>
        <source>反向搜索</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="SearchDialog.cpp" line="20"/>
        <source>查找</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="SearchDialog.cpp" line="26"/>
        <source>全字匹配</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="SearchDialog.cpp" line="27"/>
        <source>关闭</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="SearchDialog.cpp" line="28"/>
        <source>替换</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="SearchDialog.cpp" line="29"/>
        <source>全部替换</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="SearchDialog.cpp" line="33"/>
        <source>替换为:</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="SearchDialog.cpp" line="53"/>
        <source>搜索串:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>YatEdit</name>
    <message>
        <location filename="YatEdit.cpp" line="42"/>
        <source>Welcome!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="YatEdit.cpp" line="77"/>
        <source>IDE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="YatEdit.cpp" line="77"/>
        <location filename="YatEdit.cpp" line="86"/>
        <location filename="YatEdit.cpp" line="131"/>
        <location filename="YatEdit.cpp" line="137"/>
        <location filename="YatEdit.cpp" line="148"/>
        <location filename="YatEdit.cpp" line="154"/>
        <location filename="YatEdit.cpp" line="160"/>
        <location filename="YatEdit.cpp" line="166"/>
        <location filename="YatEdit.cpp" line="172"/>
        <location filename="YatEdit.cpp" line="178"/>
        <location filename="YatEdit.cpp" line="184"/>
        <location filename="YatEdit.cpp" line="190"/>
        <location filename="YatEdit.cpp" line="196"/>
        <location filename="YatEdit.cpp" line="202"/>
        <location filename="YatEdit.cpp" line="208"/>
        <source>1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="YatEdit.cpp" line="84"/>
        <source>C++</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="YatEdit.cpp" line="84"/>
        <source>C</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="YatEdit.cpp" line="84"/>
        <source>0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="YatEdit.cpp" line="86"/>
        <source>Qt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="YatEdit.cpp" line="89"/>
        <source>none</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="YatEdit.cpp" line="89"/>
        <source>-1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="YatEdit.cpp" line="109"/>
        <source>bold</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="YatEdit.cpp" line="109"/>
        <source>Bold</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="YatEdit.cpp" line="114"/>
        <source>italic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="YatEdit.cpp" line="114"/>
        <source>Italic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="YatEdit.cpp" line="119"/>
        <source>bold italic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="YatEdit.cpp" line="119"/>
        <source>Bold Italic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="YatEdit.cpp" line="131"/>
        <location filename="YatEdit.cpp" line="137"/>
        <location filename="YatEdit.cpp" line="148"/>
        <location filename="YatEdit.cpp" line="154"/>
        <location filename="YatEdit.cpp" line="160"/>
        <location filename="YatEdit.cpp" line="166"/>
        <location filename="YatEdit.cpp" line="172"/>
        <location filename="YatEdit.cpp" line="178"/>
        <location filename="YatEdit.cpp" line="184"/>
        <location filename="YatEdit.cpp" line="190"/>
        <location filename="YatEdit.cpp" line="196"/>
        <location filename="YatEdit.cpp" line="202"/>
        <location filename="YatEdit.cpp" line="208"/>
        <source>true</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="YatEdit.cpp" line="207"/>
        <location filename="YatEdit.cpp" line="462"/>
        <source>HighlightCurrentLine</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="272"/>
        <source>读取失败</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="273"/>
        <source>读取配置文件失败，是否加载默认设置？</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="286"/>
        <source>哈哈</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="YatEdit.cpp" line="310"/>
        <source>~</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="336"/>
        <source>设置配置选项失败</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="337"/>
        <source>写入配置设置时失败，维持之前的设置.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="YatEdit.cpp" line="346"/>
        <source>=IDE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="YatEdit.cpp" line="348"/>
        <source>=TextEditor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="YatEdit.cpp" line="353"/>
        <source>=C++</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="YatEdit.cpp" line="355"/>
        <source>=Qt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="YatEdit.cpp" line="357"/>
        <source>=none</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="YatEdit.cpp" line="361"/>
        <location filename="YatEdit.cpp" line="365"/>
        <location filename="YatEdit.cpp" line="469"/>
        <source>=</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="YatEdit.cpp" line="365"/>
        <source>,</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="YatEdit.cpp" line="372"/>
        <source>=Regular</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="YatEdit.cpp" line="374"/>
        <source>=Bold</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="YatEdit.cpp" line="376"/>
        <source>=Italic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="YatEdit.cpp" line="378"/>
        <source>=Bold Italic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="YatEdit.cpp" line="381"/>
        <location filename="YatEdit.cpp" line="397"/>
        <source>=%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="YatEdit.cpp" line="385"/>
        <location filename="YatEdit.cpp" line="391"/>
        <location filename="YatEdit.cpp" line="402"/>
        <location filename="YatEdit.cpp" line="409"/>
        <location filename="YatEdit.cpp" line="416"/>
        <location filename="YatEdit.cpp" line="422"/>
        <location filename="YatEdit.cpp" line="428"/>
        <location filename="YatEdit.cpp" line="434"/>
        <location filename="YatEdit.cpp" line="440"/>
        <location filename="YatEdit.cpp" line="446"/>
        <location filename="YatEdit.cpp" line="452"/>
        <location filename="YatEdit.cpp" line="458"/>
        <location filename="YatEdit.cpp" line="464"/>
        <source>=true</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="YatEdit.cpp" line="387"/>
        <location filename="YatEdit.cpp" line="393"/>
        <location filename="YatEdit.cpp" line="404"/>
        <location filename="YatEdit.cpp" line="411"/>
        <location filename="YatEdit.cpp" line="418"/>
        <location filename="YatEdit.cpp" line="424"/>
        <location filename="YatEdit.cpp" line="430"/>
        <location filename="YatEdit.cpp" line="436"/>
        <location filename="YatEdit.cpp" line="442"/>
        <location filename="YatEdit.cpp" line="448"/>
        <location filename="YatEdit.cpp" line="454"/>
        <location filename="YatEdit.cpp" line="460"/>
        <location filename="YatEdit.cpp" line="466"/>
        <source>=false</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="YatEdit.cpp" line="497"/>
        <source>/home/Xiaox/.config/YatEdit/config.YatEdit</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="505"/>
        <source>文件栏</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="510"/>
        <source>编辑栏</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="516"/>
        <source>恢复重做栏</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="521"/>
        <source>构建栏</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="YatEdit.cpp" line="535"/>
        <location filename="YatEdit.cpp" line="1555"/>
        <location filename="YatEdit.cpp" line="1558"/>
        <source>Welcome</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="537"/>
        <source>欢迎使用YatEdit,就绪!</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="557"/>
        <source>文件(&amp;F)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="559"/>
        <source>新文件(&amp;N)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="561"/>
        <source>编辑新文件</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="562"/>
        <source>建立新文件</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="564"/>
        <source>打开...(&amp;O)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="566"/>
        <source>打开文件</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="567"/>
        <source>打开一个文件</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="569"/>
        <source>保存(&amp;S)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="571"/>
        <location filename="YatEdit.cpp" line="572"/>
        <source>保存正在编辑的文件</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="575"/>
        <source>另存为(&amp;A)..</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="577"/>
        <location filename="YatEdit.cpp" line="578"/>
        <source>将文件保存到指定位置</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="581"/>
        <source>退出(&amp;E)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="583"/>
        <location filename="YatEdit.cpp" line="584"/>
        <source>退出 YatEdit</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="596"/>
        <source>编辑(&amp;E)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="597"/>
        <source>重做(&amp;R)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="598"/>
        <source>恢复</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="599"/>
        <source>恢复下一步.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="602"/>
        <source>撤销(&amp;U)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="603"/>
        <source>撤销</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="604"/>
        <source>撤销上一步.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="607"/>
        <source>查找(&amp;S)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="608"/>
        <source>查找</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="609"/>
        <source>在文本中搜索字符串.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="613"/>
        <source>替换(&amp;R)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="614"/>
        <source>查找替换</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="615"/>
        <source>在文本中搜索并替换字符串.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="619"/>
        <source>首选项(&amp;P)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="621"/>
        <source>配置选项</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="631"/>
        <source>视图(&amp;V)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="633"/>
        <source>全屏显示(&amp;F)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="637"/>
        <source>工具栏(&amp;T)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="638"/>
        <source>文件工具栏</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="640"/>
        <source>编辑工具栏</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="642"/>
        <source>撤销&amp;&amp;重做栏</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="644"/>
        <source>构建工具栏</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="651"/>
        <source>菜单栏(&amp;M)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="655"/>
        <source>锁定工具栏(L)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="656"/>
        <source>状态栏(S)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="667"/>
        <source>文本格式(&amp;F)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="668"/>
        <source>字体</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="669"/>
        <source>大小</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="YatEdit.cpp" line="674"/>
        <source>Monospace</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="YatEdit.cpp" line="678"/>
        <source>Jomolhari</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="YatEdit.cpp" line="682"/>
        <source>Console</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="YatEdit.cpp" line="686"/>
        <source>Sans</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="YatEdit.cpp" line="703"/>
        <source>4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="YatEdit.cpp" line="707"/>
        <source>8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="YatEdit.cpp" line="711"/>
        <source>12</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="YatEdit.cpp" line="715"/>
        <source>16</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="YatEdit.cpp" line="719"/>
        <source>20</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="YatEdit.cpp" line="723"/>
        <source>30</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="YatEdit.cpp" line="727"/>
        <source>48</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="750"/>
        <source>工具(&amp;E)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="752"/>
        <source>构建(&amp;B)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="753"/>
        <source>编译当前文件为可执行文件.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="755"/>
        <source>运行(&amp;R)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="756"/>
        <source>执行编译后生成的二进制文件.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="758"/>
        <source>构建并运行</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="759"/>
        <source>编译并运行</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="761"/>
        <location filename="YatEdit.cpp" line="1804"/>
        <source>带参运行</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="762"/>
        <source>为程序输入参数并执行</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="769"/>
        <source>帮助(&amp;H)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="770"/>
        <location filename="YatEdit.cpp" line="1279"/>
        <source>字数统计</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="771"/>
        <source>关于</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="772"/>
        <source>关于&amp;Qt</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="827"/>
        <source>文件夹视图</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="839"/>
        <source>编译输出</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="928"/>
        <source>是否保存更改?</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="929"/>
        <source>&lt;h2&gt;是否需要保存对以下文件所做的更改:&lt;br&gt;%1 ?&lt;/h2&gt;若选择否,足下之前所进行的更改将永久丢失.&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="971"/>
        <source>新标签页已创建</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="YatEdit.cpp" line="972"/>
        <location filename="YatEdit.cpp" line="1092"/>
        <location filename="YatEdit.cpp" line="1143"/>
        <location filename="YatEdit.cpp" line="1344"/>
        <location filename="YatEdit.cpp" line="1371"/>
        <location filename="YatEdit.cpp" line="1674"/>
        <source>~newfile~</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="985"/>
        <source>打开</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="987"/>
        <location filename="YatEdit.cpp" line="1118"/>
        <source>所有文件 (*)</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="1010"/>
        <source>打开成功.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="YatEdit.cpp" line="1036"/>
        <source>/</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="1099"/>
        <source>抱歉,当前文件已是最新,
无事可做.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="1116"/>
        <source>保存到..</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="1136"/>
        <source>是否重新加载?</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="1137"/>
        <source>此文档自打开以来已被更改.
足下是否决定从新加载更改后的内容&lt;OK&gt;
还是保持当前状态&lt;NO&gt;?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="YatEdit.cpp" line="1143"/>
        <location filename="YatEdit.cpp" line="1156"/>
        <location filename="YatEdit.cpp" line="1157"/>
        <location filename="YatEdit.cpp" line="1163"/>
        <source>~unsaved~</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="1164"/>
        <source>当前文件未被保存.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="1194"/>
        <source>搜索</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="1217"/>
        <location filename="YatEdit.cpp" line="1223"/>
        <source>查找失败</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="1217"/>
        <source>查找失败：已到文件头.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="1223"/>
        <source>查找失败：已到文件尾,回到文件头继续查找.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="1239"/>
        <source>提醒：未输入字符串.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="1262"/>
        <source>已找到并替换 %1 处. </source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="1271"/>
        <source>搜索和替换</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="1279"/>
        <source>文档字数：%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="YatEdit.cpp" line="1285"/>
        <location filename="YatEdit.cpp" line="1294"/>
        <source>YatEdit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="YatEdit.cpp" line="1286"/>
        <source>A simple code editor from China.
</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="1295"/>
        <source>不能保存文件 %1:
%2.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="1313"/>
        <source> 保存成功</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="1354"/>
        <source>不能创建标签页</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="1355"/>
        <source>不能继续创建标签页，因为足下创建数目已达上限: 50</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="1630"/>
        <source>						第%1行,第%2列</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="1658"/>
        <source>文档自动保存中...完毕</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="1668"/>
        <source>文件未保存，无事可做.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="1675"/>
        <location filename="YatEdit.cpp" line="1709"/>
        <location filename="YatEdit.cpp" line="1751"/>
        <location filename="YatEdit.cpp" line="1773"/>
        <source>错误</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="1676"/>
        <source>错误:未更改的新文件 ~newfile~，无事可做.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="1686"/>
        <location filename="YatEdit.cpp" line="1692"/>
        <source>不能构建</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="1687"/>
        <source>不能打开输出文件，编译终止.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="1693"/>
        <source>不能重定向标准输出,编译终止.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="1699"/>
        <source>***构建开始***
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="YatEdit.cpp" line="1703"/>
        <source>cpp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="YatEdit.cpp" line="1704"/>
        <source>c++ -Wall </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="YatEdit.cpp" line="1704"/>
        <location filename="YatEdit.cpp" line="1706"/>
        <source> -o </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="YatEdit.cpp" line="1705"/>
        <source>c</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="YatEdit.cpp" line="1706"/>
        <source>gcc -Wall </source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="1708"/>
        <source>***编译错误，放弃.***</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="1710"/>
        <source>错误:文件格式错误,编译终止.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="1713"/>
        <source>警告</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="1714"/>
        <source>警告:文件关闭错误.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="1717"/>
        <source>文件为空</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="1718"/>
        <source>文件名为空，编译终止.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="1720"/>
        <location filename="YatEdit.cpp" line="1779"/>
        <source>****完成****
</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="1752"/>
        <source>错误:文件 %1 不存在，不能执行.
您也许应该先编译此文件.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="1758"/>
        <source>不能运行</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="1759"/>
        <source>不能创建文件，运行失败.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="1764"/>
        <source>不能执行</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="1765"/>
        <source>不能重定向标准输出,执行终止.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="1770"/>
        <source>***开始运行***
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="YatEdit.cpp" line="1772"/>
        <source>xterm -e </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="YatEdit.cpp" line="1772"/>
        <source> </source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="1774"/>
        <source>程序执行错误,异常退出.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="1775"/>
        <source>***异常退出***
</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="1805"/>
        <source>输入参数：</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="1806"/>
        <source>运行</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="YatEdit.cpp" line="1807"/>
        <source>关闭</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>lookConfigPage</name>
    <message>
        <location filename="ConfigPages.cpp" line="178"/>
        <source>Look for packages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ConfigPages.cpp" line="180"/>
        <source>Name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ConfigPages.cpp" line="183"/>
        <source>Released after:</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="ConfigPages.cpp" line="186"/>
        <source>显示行号</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="ConfigPages.cpp" line="188"/>
        <source>高亮显示当前行</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ConfigPages.cpp" line="192"/>
        <source>Return up to </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ConfigPages.cpp" line="193"/>
        <source> results</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ConfigPages.cpp" line="194"/>
        <source>Return only the first result</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ConfigPages.cpp" line="199"/>
        <source>Start query</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>viewConfigPage</name>
    <message>
        <location filename="ConfigPages.cpp" line="139"/>
        <source>Package selection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ConfigPages.cpp" line="140"/>
        <source>Update system</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ConfigPages.cpp" line="141"/>
        <source>Update applications</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ConfigPages.cpp" line="142"/>
        <source>Update documentation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ConfigPages.cpp" line="144"/>
        <source>Existing packages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ConfigPages.cpp" line="148"/>
        <source>Qt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ConfigPages.cpp" line="150"/>
        <source>QSA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ConfigPages.cpp" line="152"/>
        <source>Teambuilder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ConfigPages.cpp" line="154"/>
        <source>Start update</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
