/****************************YatEdit********************************
*********Copyright @ 吴平杰 (Pingjie Wu) from China,2011*********
*******************************************************************/
/*
  搜索与替换对话框的成员函数实现。
*/

#include"SearchDialog.h"
#include<QHBoxLayout>

SearchDialog::SearchDialog(QWidget *parent)
    :QDialog(parent)
{
	setWindowTitle(trUtf8("搜索"));
    input=new QLineEdit;
    input->setFixedSize(320,28);
    replaceTextEdit=new QLineEdit;
    replaceTextEdit->setFixedSize(320,28);
	findBack=new QCheckBox(trUtf8("反向搜索"));
	findNext=new QPushButton(trUtf8("查找"));

   // buttonBox=new QDialogButtonBox(Qt::Vertical);
    //buttonBox->addButton(findBack, QDialogButtonBox::ActionRole);
    //buttonBox->addButton(findNext, QDialogButtonBox::ActionRole);

	wholeWord=new QCheckBox(trUtf8("全字匹配"));
	exitButton=new QPushButton(trUtf8("关闭"));
	replaceButton=new QPushButton(trUtf8("替换"));
	replaceAll=new QCheckBox(trUtf8("全部替换"));


    QHBoxLayout *repLayout=new QHBoxLayout;
	repLayout->addWidget(new QLabel(trUtf8("替换为:")));
    repLayout->addWidget(replaceTextEdit);
    repLayout->addWidget(findBack);

    QHBoxLayout *extLayout=new QHBoxLayout;
    extLayout->addWidget(wholeWord);
    extLayout->addWidget(replaceAll);
    extLayout->addWidget(exitButton);
    extLayout->addWidget(replaceButton);

    extension=new QWidget;
    extVLayout=new QVBoxLayout;
    extVLayout->addLayout(repLayout);
    extVLayout->addLayout(extLayout);
    extVLayout->setAlignment(Qt::AlignLeft);
    extension->setLayout(extVLayout);



    hLayout=new QHBoxLayout;
	hLayout->addWidget(new QLabel(trUtf8("搜索串:")));
    hLayout->addWidget(input);
    hLayout->addWidget(findNext);

    QVBoxLayout *main=new QVBoxLayout;
    main->addLayout(hLayout);
    main->addWidget(extension);

    setLayout(main);

    setupSignals();
}

//信号与槽
void SearchDialog::setupSignals()
{
    connect(exitButton,SIGNAL(clicked()),this,SLOT(close()));
}

//相对于搜索对话框，替换对话框需要额外的控制按钮
void SearchDialog::showExtension(bool yes)
{
    if(yes)
        extension->setVisible(true);
    else
        extension->setVisible(false);
}
