/****************************YatEdit********************************
*********Copyright @ 吴平杰 (Pingjie Wu) from China,2011*********
*******************************************************************/
/*
  配置对话框里面的三个分类页面，editConfigPage,viewConfigPage,lookConfigPage
  的定义。在初始阶段接受用configOptions传递的参数。
*/

#include"ConfigPages.h"


editConfigPage::editConfigPage(configOptions options,QWidget *parent)
    : QWidget(parent)
{
	QGroupBox *configGroup = new QGroupBox(trUtf8("YatEdit 模式与文本选项"));

	QLabel *modeLabel = new QLabel(trUtf8("YatEdit 模式:"));
	modeCombo = new QComboBox;
	modeCombo->addItem(trUtf8("简单的集成开发环境IDE"));
	modeCombo->addItem(trUtf8("纯文本编辑器TextEditor)"));
	modeCombo->setCurrentIndex(options.ProgramMode-1);

	QLabel *highlightLabel = new QLabel(trUtf8("语法高亮模式:"));
	highlightCombo = new QComboBox;
	highlightCombo->addItem(trUtf8("C/C++ 源代码"));
	highlightCombo->addItem(trUtf8("Qt 源代码"));
	highlightCombo->addItem(trUtf8("C# 源代码"));
	highlightCombo->addItem(trUtf8("Java 源代码"));
	highlightCombo->addItem(trUtf8("Makefile"));
	highlightCombo->addItem(trUtf8("Linux Shell"));
	highlightCombo->addItem(trUtf8("纯文本"));
	highlightCombo->setCurrentIndex(options.TextHighlightMode);

	QLabel *editBackgroundLabel=new QLabel(trUtf8("编辑区背景色："));
	editBackgroundSelecter=new QPushButton;
	editBackgroundSelecter->setFlat(true);
	editBackgroundSelecter->setAutoFillBackground(true);
	editBackgroundSelecter->setPalette(QPalette(QColor(options.BackgroundColor)));

	selectColor=new QColorDialog(this);
	selectColor->setWindowTitle(trUtf8("选择编辑区背景颜色"));
	connect(editBackgroundSelecter,SIGNAL(clicked()),selectColor,SLOT(show()));
	connect(selectColor,SIGNAL(colorSelected(QColor)),this,SLOT(selectBackgroundColor(QColor)));

	QLabel *editFontLabel=new QLabel(trUtf8("编辑字体："));
	editFontSelecter=new QPushButton(trUtf8(options.TextFont.toString().toUtf8()).split(",").first());
	editFontSelecter->setFont(options.TextFont);
	editFontSelecter->setFlat(true);
	textFont=new QFontDialog(options.TextFont);
	textFont->setWindowTitle(trUtf8("选择文本字体"));
	connect(editFontSelecter,SIGNAL(clicked()),textFont,SLOT(show()));
	connect(textFont,SIGNAL(fontSelected(QFont)),this,SLOT(selectTextFont(QFont)));

	QLabel *tabLabel=new QLabel(trUtf8("Tab键宽度:"));
	tabWidth=new QSpinBox;
	//tabWidth->setSuffix("  sec");
	tabWidth->setMaximum(16);
	tabWidth->setMinimum(1);
	tabWidth->setValue(options.TabWidth/10);

	autoIndent=new QCheckBox(trUtf8("C代码自动缩进"));
	autoIndent->setChecked(false);

	autoBackup=new QCheckBox(trUtf8("自动生成备份"));
	autoIndent->setChecked(false);

	autoSave=new QCheckBox(trUtf8("自动保存"));
	autoSave->setChecked(options.AutoSaveTime);

	QLabel *autoSaveLabel=new QLabel(trUtf8("自动保存时间间隔"));
	autoSaveTime=new QSpinBox;
	autoSaveTime->setSuffix(trUtf8("  分钟"));
	autoSaveTime->setMaximum(360);
	autoSaveTime->setMinimum(0);
	autoSaveTime->setValue(options.AutoSaveTime);
	autoSaveTime->setEnabled(options.AutoSaveTime);
	connect(autoSave,SIGNAL(toggled(bool)),autoSaveTime,SLOT(setEnabled(bool)));

	QHBoxLayout *modeLayout = new QHBoxLayout;
	modeLayout->addWidget(modeLabel);
	modeLayout->addWidget(modeCombo);

	QHBoxLayout *highlightLayout = new QHBoxLayout;
	highlightLayout->addWidget(highlightLabel);
	highlightLayout->addWidget(highlightCombo);

	QHBoxLayout *editBackgroundColorLayout = new QHBoxLayout;
	editBackgroundColorLayout->addWidget(editBackgroundLabel);
	editBackgroundColorLayout->addWidget(editBackgroundSelecter);

	QHBoxLayout *editFontLayout = new QHBoxLayout;
	editFontLayout->addWidget(editFontLabel);
//	editFontLayout->addWidget(fontTestLabel);
	editFontLayout->addWidget(editFontSelecter);

	QHBoxLayout *tabWidthLayout = new QHBoxLayout;
	tabWidthLayout->addWidget(tabLabel);
//	editFontLayout->addWidget(fontTestLabel);
	tabWidthLayout->addWidget(tabWidth);

	QHBoxLayout *autoSaveLayout = new QHBoxLayout;
	autoSaveLayout->addWidget(autoSaveLabel);
	autoSaveLayout->addWidget(autoSaveTime);

	QVBoxLayout *configLayout = new QVBoxLayout;
	configLayout->addLayout(modeLayout);
	configLayout->addLayout(highlightLayout);
	configLayout->addLayout(editBackgroundColorLayout);
	configLayout->addLayout(editFontLayout);
	configLayout->addLayout(tabWidthLayout);
	configLayout->addWidget(autoIndent);
	configLayout->addWidget(autoSave);
	configLayout->addLayout(autoSaveLayout);
	configLayout->setAlignment(Qt::AlignVCenter);

    configGroup->setLayout(configLayout);

	QVBoxLayout *mainLayout = new QVBoxLayout;
    mainLayout->addWidget(configGroup);
    mainLayout->addStretch(1);
    setLayout(mainLayout);
}

void editConfigPage::selectBackgroundColor(QColor color)
{
	//editBackgroundSelecter->de
	editBackgroundSelecter->setPalette(QColor(color));
}

void editConfigPage::selectTextFont(QFont font)
{
	editFontSelecter->setText(font.toString().split(",").first());
	editFontSelecter->setFont(font);
}

viewConfigPage::viewConfigPage(configOptions options,QWidget *parent)
    : QWidget(parent)
{
	QGroupBox *updateGroup = new QGroupBox(trUtf8("Package selection"));
	QCheckBox *systemCheckBox = new QCheckBox(trUtf8("Update system"));
	QCheckBox *appsCheckBox = new QCheckBox(trUtf8("Update applications"));
	QCheckBox *docsCheckBox = new QCheckBox(trUtf8("Update documentation"));

	QGroupBox *packageGroup = new QGroupBox(trUtf8("Existing packages"));

    QListWidget *packageList = new QListWidget;
    QListWidgetItem *qtItem = new QListWidgetItem(packageList);
	qtItem->setText(trUtf8("Qt"));
    QListWidgetItem *qsaItem = new QListWidgetItem(packageList);
	qsaItem->setText(trUtf8("QSA"));
    QListWidgetItem *teamBuilderItem = new QListWidgetItem(packageList);
	teamBuilderItem->setText(trUtf8("Teambuilder"));

	QPushButton *startUpdateButton = new QPushButton(trUtf8("Start update"));

    QVBoxLayout *updateLayout = new QVBoxLayout;
    updateLayout->addWidget(systemCheckBox);
    updateLayout->addWidget(appsCheckBox);
    updateLayout->addWidget(docsCheckBox);
    updateGroup->setLayout(updateLayout);

    QVBoxLayout *packageLayout = new QVBoxLayout;
    packageLayout->addWidget(packageList);
    packageGroup->setLayout(packageLayout);

    QVBoxLayout *mainLayout = new QVBoxLayout;
    mainLayout->addWidget(updateGroup);
    mainLayout->addWidget(packageGroup);
    mainLayout->addSpacing(12);
    mainLayout->addWidget(startUpdateButton);
    mainLayout->addStretch(1);
    setLayout(mainLayout);
}

lookConfigPage::lookConfigPage(configOptions options,QWidget *parent)
    : QWidget(parent)
{
	QGroupBox *packagesGroup = new QGroupBox(trUtf8("Look for packages"));

	QLabel *nameLabel = new QLabel(trUtf8("Name:"));
    QLineEdit *nameEdit = new QLineEdit;

	QLabel *dateLabel = new QLabel(trUtf8("Released after:"));
    QDateTimeEdit *dateEdit = new QDateTimeEdit(QDate::currentDate());

	LineNumber = new QCheckBox(trUtf8("显示行号"));
	LineNumber->setChecked(options.LineNumber);
	HighlightCurLine = new QCheckBox(trUtf8("高亮显示当前行"));
	HighlightCurLine->setChecked(options.HighlightCurrentLine);

    QSpinBox *hitsSpinBox = new QSpinBox;
	hitsSpinBox->setPrefix(trUtf8("Return up to "));
	hitsSpinBox->setSuffix(trUtf8(" results"));
	hitsSpinBox->setSpecialValueText(trUtf8("Return only the first result"));
    hitsSpinBox->setMinimum(1);
    hitsSpinBox->setMaximum(100);
    hitsSpinBox->setSingleStep(10);

	QPushButton *startQueryButton = new QPushButton(trUtf8("Start query"));

    QGridLayout *packagesLayout = new QGridLayout;
    packagesLayout->addWidget(nameLabel, 0, 0);
    packagesLayout->addWidget(nameEdit, 0, 1);
    packagesLayout->addWidget(dateLabel, 1, 0);
    packagesLayout->addWidget(dateEdit, 1, 1);
	packagesLayout->addWidget(LineNumber, 2, 0);
	packagesLayout->addWidget(HighlightCurLine, 3, 0);
    packagesLayout->addWidget(hitsSpinBox, 4, 0, 1, 2);
    packagesGroup->setLayout(packagesLayout);

    QVBoxLayout *mainLayout = new QVBoxLayout;
    mainLayout->addWidget(packagesGroup);
    mainLayout->addSpacing(12);
    mainLayout->addWidget(startQueryButton);
    mainLayout->addStretch(1);
    setLayout(mainLayout);
}
