/****************************YatEdit********************************
*********Copyright @ 吴平杰 (Pingjie Wu) from China,2011*********
*******************************************************************/
/*
  编辑工具栏与文件工具栏的单独实现，这是一大败笔。因为刚开始写没有考虑周全，
  轻率地将其单独实现。要改也未尝不可，只是牵一发而动全身，
  有点麻烦，所以只好将就一下了。
*/

#include"ToolBars.h"

FileToolBars::FileToolBars()
{
	newFileAct=new QAction(QIcon("/home/xiao/.config/YatEdit/images/new.svg"),trUtf8("新文件"),this);
	newFileAct->setStatusTip(trUtf8("创建一个新文件."));
	
	openFileAct=new QAction(QIcon("/home/xiao/.config/YatEdit/images/open.svg"),trUtf8("打开"),this);
	openFileAct->setStatusTip(trUtf8("打开一个文件."));

	saveFileAct=new QAction(QIcon("/home/xiao/.config/YatEdit/images/save.svg"),trUtf8("保存"),this);
	saveFileAct->setStatusTip(trUtf8("保存当前文件."));

	saveAsFileAct=new QAction(QIcon("/home/xiao/.config/YatEdit/images/save-as.svg"),trUtf8("另存为.."),this);
	saveAsFileAct->setStatusTip(trUtf8("将当前文件保存到指定位置."));

	this->addAction(newFileAct);
	this->addAction(openFileAct);
	this->addAction(saveFileAct);
	this->addAction(saveAsFileAct);
}

QAction* FileToolBars::newAct()
{
	return newFileAct;
}

QAction* FileToolBars::openAct()
{
	return openFileAct;
}

QAction* FileToolBars::saveAct()
{
	return saveFileAct;
}

QAction* FileToolBars::saveAsAct()
{
	return saveAsFileAct;
}



EditToolBars::EditToolBars()
{
		copyEditAct=new QAction(QIcon("/home/xiao/.config/YatEdit/images/copy.svg"),trUtf8("复制"),NULL);
		copyEditAct->setStatusTip(trUtf8("复制选定文本"));
		
		pasteEditAct=new QAction(QIcon("/home/xiao/.config/YatEdit/images/paste.svg"),trUtf8("粘贴"),this);
		pasteEditAct->setStatusTip(trUtf8("在当前位置粘贴"));

		cutEditAct=new QAction(QIcon("/home/xiao/.config/YatEdit/images/cut.svg"),trUtf8("剪贴"),this);
		cutEditAct->setStatusTip(trUtf8("剪切当前文本"));

		this->addAction(copyEditAct);
		this->addAction(pasteEditAct);
		this->addAction(cutEditAct);
}

QAction* EditToolBars::copyAct()
{
	return copyEditAct;
}

QAction* EditToolBars::pasteAct()
{
	return pasteEditAct;
}

QAction* EditToolBars::cutAct()
{
	return cutEditAct;
}
